#ifndef _DAY_5_H_
#define _DAY_5_H_

void printBinary(unsigned int num);				//Question 1
int findNumberGreater(unsigned int num);		//Question 2
int isPowerOfTwo(unsigned int num);				//Question 3
int findNumberOdd(int arr[], int n);			//Question 4
unsigned int reverseAllBits(unsigned int num);	//Question 5
int countDifferentBit(int x, int y);			//Count bit different
int sumOfF(int arr[], int n);					//Question 6

#endif /*end of file*/

