#ifndef _DAY_6_H_
#define _DAY_6_H_

int sumOfNaturalNumbers(int num);				//Question 1
int findFactorialOfANumber(int num);			//Question 2
int findGCD(int num1, int num2);				//Question 3
int countDigits(int num);						//Question 4
int sumOfDigits(int num);						//Question 5
int getLargestElement(int arr[], int n);		//Question 6
void reverseString(char str[], int len);		//Question 7
void convertToBinary(int num);					//Question 8
int isPrimeNumber(int num, int i);				//Question 9

#endif /*end of file*/
