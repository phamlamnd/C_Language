#include "Day7.h"
#include <stdio.h>

int main()
{
	FILE *fp;
	
	/*Question 1*/
	//writeToFileNew("Question1.txt");
	
	/*Question 2*/
	//writeToFileAppended("Question2.txt");
	
	/*Question 3*/
	/*struct Student Array[MAX];
	int n; //number of student
	inputArrayStudent(Array, &n);
	writeArrayToFile(Array, n, "Question3.txt");
	readFileAndDislay("Question3.txt");*/
	
	/*Question 4*/
	//copyFile("file1.txt", "file2.txt");
	
	/*Question 6*/
	//deleteFile("file1.txt");
	
	/*Question 7*/
	//mergeFile("file1.txt", "file2.txt", "file3.txt");
	
	/*Question 8*/
	printf("count number line: %d", countNumberLines("file1"));

	return 0;
}

